// 미리 선언해둔 함수 호출
App.onJoinPlayer.Add(function(player){  //player가 참여했을 때 실행할 함수
    // App.showCenterLabel("Hello Sparta") //중앙에 라벨 띄우기

    // 스피드 조작
    player.moveSpeed = 300;
    player.sendUpdated();       //업데이트
})